# -*- coding: utf-8 -*-
"""
Created on Sat Aug  8 16:11:13 2015
Description:
Inputs:
Outputs:
@author: Gurunath Reddy M

"""

import numpy as np
from scipy.signal import _savitzky_golay as savgol_filter
import matplotlib.pyplot as plt
import waveio as io
import zff as zff
from scipy.signal import get_window
import f0Detect as f0Detect
import dftStft as stft
from scipy.signal import medfilt

(fs, x) = io.wavread('../wave/Scale A#Mono.wav')      # Read the samples of input wavefile
x = np.array(x, np.float64)                 # Convert the samples to matlab double data type
x = x/(1.01*np.max(np.abs(x)));             # Normalize sample values
x = x - np.mean(x)                          # Perform mean subtraction to remove DC bias                

trainSampBeg = np.array([1721600, 1976320, 2203648, 2433024, 2636288, 2850816, 3066880, 3309056])
trainSampEnd = np.array([1842688, 2093696, 2323072, 2538624, 2738304, 2955904, 3191936, 3411968])

testSampBeg = np.array([1852032, 2094080, 2322432, 2540544, 2742784, 2965504, 3194368, 3411968])
testSampEnd = np.array([1972224, 2201216, 2432128, 2636416, 2846336, 3064448, 3308160, 3493632])

notesNames = ['sa', 'ri', 'ga', 'ma', 'pa', 'da', 'ni', 'sah'] 
# Save train nate and test notes as wave files
numNotes = np.size(trainSampBeg)
trainDir = '../train_notes/'
testDir = '../test_notes/'

for i in range(numNotes):
    tempNoteNameTrain = trainDir + notesNames[i] + '.wav'
    tempNoteNameTest = testDir + notesNames[i] + '.wav'
    tempTrain = x[trainSampBeg[i]:trainSampEnd[i]]
    tempTest = x[testSampBeg[i]:testSampEnd[i]]
    io.wavwrite(tempTrain, fs, tempNoteNameTrain)
    io.wavwrite(tempTest, fs, tempNoteNameTest)

# ----------------------------------------------------------------------------------------------------- #
trainFilePath = trainDir + notesNames[0] + '.wav'
(fs, xtrain) = io.wavread(trainFilePath)    # Read train sample note
xtrain = np.array(xtrain, np.float64)                       # Convert the samples to matlab double data type
xtrain = xtrain/(1.01*np.max(np.abs(xtrain)));              # Normalize sample values
xtrain = xtrain - np.mean(xtrain)                                # Perform mean subtraction to remove DC bias                

testFilePath = testDir + notesNames[2] + '.wav'
(fs, xtest) = io.wavread(testFilePath)    # Read train sample note
xtest = np.array(xtest, np.float64)                       # Convert the samples to matlab double data type
xtest = xtest/(1.01*np.max(np.abs(xtest)));              # Normalize sample values
xtest = xtest - np.mean(xtest)                                # Perform mean subtraction to remove DC bias                

M = 1024
N = 2048
H = M/4
window = 'blackmanharris'
w = get_window(window, M)
mxTrain, pxTrain = stft.stftAnal(xtrain, fs, w, N, H) # mx and px are the magnitude and phase spectrum

# Applay ZFF and get the pitch contours
# Calling TWM to get the representative centre of frequency for each note. 
t = -60.0           # Magnitude threshold for TWM
minf0 = 100
maxf0 = 1000
f0etr = 5           # Error threshold in HZ

# Performing TWM to get the f0 contour
f0 = f0Detect.f0Detection(mxTrain, fs, N, t, minf0, maxf0, f0etr)        # Getting f0 by TWM
# Clean obtained f0
f0MedFilt = medfilt(f0, 3)
f0MedFilt = medfilt(f0MedFilt, 5)
plt.plot(f0MedFilt)


#lengthX = np.shape(x)[0]
#windSize = 4 # Choose ZFF mean subtraction window emperically as 4ms for v/uv classification
#[zsp1, gclocssp1, epssp1, f0sp1] = zff.zff(x, fs, windSize) # Compute the zff of x
