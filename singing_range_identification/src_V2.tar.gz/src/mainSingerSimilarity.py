# -*- coding: utf-8 -*-
"""
Created on Sat Aug  8 16:11:13 2015
Description:
Inputs:
Outputs:
@author: Gurunath Reddy M

"""

import numpy as np
from scipy.signal import _savitzky_golay as savgol_filter
import matplotlib.pyplot as plt
import zff as zff

import sys, os
import subprocess
import singerReadWav as sigRedWav
import singerCompMagSpect as sigCompMagSpec
import singerTWM as sigTWM
import smooth as smooth
import singerZffF0 as sigZffF0
import scipy.io as io
import singerMelodySalienceBased as singMelSali
sys.path.append(os.path.join(os.path.dirname(os.path.realpath('__file__')), '../../../software/models/'))
import utilFunctions as UF
import time

notesNames = ['sa', 'ri', 'ga', 'ma', 'pa', 'da', 'ni', 'sah']  # Notes to be identified
notesAvgFreq = np.array([236, 264, 290, 300, 345, 391, 440, 463])
trainDir = '../train_notes/'                                    # Directory where train notes are present
testDir = '../test_notes/'                                      # Directory where test notes are present

#M = 1024
#N = 2048
#H = M/4
#window = 'blackmanharris'

getNoteName = raw_input('Enter the note name you want to practice: ')
print "You will be going to hear the note " + getNoteName + '' + 'in next 4Sec'
subprocess.call(['festival', '--tts', 'prompt.txt'])
trainNoteFileName = trainDir + getNoteName + '.wav'
time.sleep(4)
subprocess.call(['aplay', trainNoteFileName])

print "Get ready for your turn to record the note you have just listened " + getNoteName + '' + 'in next 4Sec'
#time.sleep(4)
subprocess.call(['festival', '--tts', 'prompt.txt'])
subprocess.call(['arecord',  '-r', '44100', '-d', '5', '../record/test.wav'])
print "This what you have recorded"
subprocess.call(['aplay', '../record/test.wav'])

#noteName = notesNames[5]                                                            # Select availabel note
#fileName = testDir + notesNames + '.wav'
indexOfNote = notesNames.index(getNoteName)
fileName = '../record/test.wav'
pitch = singMelSali.getTraineeMelody(fileName)
meanPitch = np.mean(pitch[pitch>0])


if(meanPitch >= notesAvgFreq[indexOfNote]-10 and meanPitch <= notesAvgFreq[indexOfNote]+10):
    print "Your pitch range is comparable with the singers pitch range"
else:
    print "You can try one more time"
        
print 'Your sung Melody will be played in next 4Sec'       
subprocess.call(['festival', '--tts', 'prompt.txt'])
hopSize = 128
sampleRate = 44100
yf0 = UF.sinewaveSynth(pitch, .6, hopSize, sampleRate)
UF.wavwrite(yf0, sampleRate, 'traineeMelody.wav')
plt.plot(pitch)
subprocess.call(['aplay', 'traineeMelody.wav'])


#fsTrian, xTrain = sigRedWav.readWavfiles(trainDir, noteName)                        # Reads each note
#mxTrain, pxTrain = sigCompMagSpec.compMagSpect(xTrain, window, N, M, H, fsTrian)    # Computes Mag. and Phase spectrograms
#f0TWM = sigTWM.computTWM(mxTrain, N, fsTrian)                                       # Identifies resonance frequency for ZFF filtering
#plt.plot(f0TWM)                                             
#
#windSize = 2.5                                    # Choose ZFF mean subtraction window emperically as 4ms for v/uv classification
#noteF0Train = sigZffF0.getZFFsF0(xTrain, fsTrian, windSize)
#
#diffNoteF0Train = np.diff(noteF0Train)
#absDiff = np.abs(diffNoteF0Train)
#meanDiff = np.mean(absDiff)
#requIndi = np.where(absDiff <= meanDiff)[0]
#tempF0 = noteF0Train[requIndi]
#diffTempF0 = np.abs(np.diff(tempF0))
#meanTempF0 = np.mean(diffTempF0)
#indxActualTrainMelody = np.where(diffTempF0 < meanTempF0)[0]
#actualF0TrainMelody = noteF0Train[indxActualTrainMelody]
#plt.figure()
#plt.plot(noteF0Train)
##plt.plot(actualF0TrainMelody)
#
#
#io.savemat('../train_melodies/'+ noteName+'.mat', mdict={noteName:noteF0Train})
#noteFreq = io.loadmat('../train_melodies/'+noteName+'.mat', struct_as_record=True)
#freq = np.reshape(noteFreq[noteName], -1)
#plt.plot(freq)
#
#noteName = notesNames[7]
#windSize = 5 # Choose ZFF mean subtraction window emperically as 4ms for v/uv classification
#fsTrian, xTrain = sigRedWav.readWavfiles(trainDir, noteName)
#noteF0Train = sigZffF0.getZFFsF0(xTrain, fsTrian, windSize)
#plt.plot(noteF0Train)
#
#fsTest, xTest = sigRedWav.readWavfiles(testDir, noteName)
#noteF0Test = sigZffF0.getZFFsF0(xTest, fsTest, windSize)
#plt.plot(noteF0Test)
